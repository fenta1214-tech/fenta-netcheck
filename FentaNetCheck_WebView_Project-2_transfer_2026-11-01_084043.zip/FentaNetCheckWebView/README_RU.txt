Fenta NetCheck — Android WebView project
========================================

Это ИСХОДНИКИ Android-приложения. Это ещё не готовый APK.

Что внутри:
- HTML-приложение app/src/main/assets/index.html
- Android WebView с JavaScript и DOM storage
- INTERNET и VIBRATE permissions
- внешние HTTP/HTTPS-ссылки открываются в браузере
- включён полноэкранный режим WebView

Как собрать APK на компьютере:
1. Установить Android Studio.
2. Распаковать архив.
3. В Android Studio выбрать Open и указать папку FentaNetCheckWebView.
4. Дождаться Gradle Sync и установить нужные Android SDK (compileSdk 35).
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK обычно появится в app/build/outputs/apk/debug/app-debug.apk.

Важно:
- Для сборки нужен интернет, Android SDK и JDK 17.
- Я не смог собрать APK непосредственно в этой среде: здесь нет установленного Android SDK/Gradle.
- В текущем HTML проверка сайтов использует браузерные fetch/Image механизмы; результаты приблизительные.
- При загрузке через file:// некоторые Android WebView могут ограничивать сетевые запросы и/или localStorage.
- Telegram-запросы из локального HTML могут блокироваться CORS. Для надёжной работы Telegram понадобится проверка на устройстве и, возможно, прокси-сервер.
- Системные Web Notification API внутри WebView поддерживаются не так же, как в обычном браузере; для полноценных Android-уведомлений нужна отдельная нативная интеграция.
- Токен Telegram хранится в localStorage. Не используй общий/чужой телефон и не передавай APK с сохранённым токеном.
